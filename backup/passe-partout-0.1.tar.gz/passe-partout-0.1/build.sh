#!/bin/sh
make -f Makefile.`uname` clean
make -f Makefile.`uname`
